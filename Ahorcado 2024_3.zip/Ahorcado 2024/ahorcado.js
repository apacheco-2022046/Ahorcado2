let palabraActual;
let botones;
let palabrasAdivinadas = 0;
let intentos = 0;
const canvas = document.getElementById("grafico")
const context = canvas.getContext("2d")
const listPalabras = ["oso", "futbolista","mysql","informática", "periodico","musica", "dinero"]

const palabras = () => {
    const lista = listPalabras [Math.floor(Math.random()* listPalabras.length)]
    console.log(palabraActual);
}

palabras();


function lineas (palabraActual, x, y,){
    var longitud = palabraActual.length;
    var longitudLinea = longitud * 10; 
    context.beginPath();
    context.moveTo(x, y);
    context.lineTo(x + longitudLinea, y);
    context.stroke();
}